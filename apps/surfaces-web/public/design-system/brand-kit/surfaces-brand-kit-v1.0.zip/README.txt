Surfaces Brand Kit v1.0
Updated June 16, 2026

Contents
- Active logo SVGs
- Favicon and app icon SVGs
- Social card SVG
- Brand token JSON
- Product token JSON
- CSS token and component layer

Usage
- Use the wordmark whenever space allows.
- Use the compact mark at 32 px and above where the wordmark will not hold.
- Use the small mark for favicon, 16 px, and 24 px placements.
- Keep brand expression grayscale.
- Use semantic product color only for state, validation, focus, alerts, selection, or data meaning.
- Do not stretch, recolor, outline, rotate, shadow, or redraw the identity.
