Surfaces Simple Slab brand kit
Version 0.2.0

Source: /Users/mike/SurfacesBrand/current/simple-slab-mark/agent-package

Use the Simple Slab mark, current lockups, public-page tokens, and CSS variables in this package. Proof Cyan is a small evidence signal only; do not use it as mark geometry, a glow, a rail, or a blue theme.
